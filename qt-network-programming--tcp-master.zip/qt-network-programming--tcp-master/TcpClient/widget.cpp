#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    TcpSocket = new QTcpSocket; //创建一个新的QTcpSocket类对象
}

Widget::~Widget()
{
    delete ui;
}

void Widget::on_open_bt_clicked()
{
    TcpSocket->connectToHost(ui->ip_address->text(),ui->port_num->text().toUInt());//连接到服务器
    connect(TcpSocket,SIGNAL(connected()),this,SLOT(Connect_Slot()));//关联槽函数，一旦有连接信号产生，就会执行槽函数内的命令
}
void Widget::Connect_Slot()
{
    connect(TcpSocket,SIGNAL(readyRead()),this,SLOT(ReadyRead_Slot()));//当连接好后，进入这个槽函数，一旦有读取信号的产生，就执行读取槽函数

}
void Widget::ReadyRead_Slot()
{
    ui->data_receive->appendPlainText(TcpSocket->readAll());//将读取到的内容直接以append的形式传入data_receive控件中
}

void Widget::on_close_bt_clicked()
{
    TcpSocket->close();//关闭socket（客户端）
}

void Widget::on_send_bt_clicked()
{
    TcpSocket->write(ui->data_edit->text().toLocal8Bit().data());//将data_edit控件中的内容都发送出去
}
