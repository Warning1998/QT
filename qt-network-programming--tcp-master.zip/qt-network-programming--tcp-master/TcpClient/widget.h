#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QTcpSocket>
namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = nullptr);
    ~Widget();
    QTcpSocket* TcpSocket;//新建的QTcpSocket类

private slots://槽函数
    void on_open_bt_clicked();
    void Connect_Slot();
    void ReadyRead_Slot();
    void on_close_bt_clicked();
    void on_send_bt_clicked();

private:
    Ui::Widget *ui;
};

#endif // WIDGET_H
