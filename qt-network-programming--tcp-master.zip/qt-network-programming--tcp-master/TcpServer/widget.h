#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QTcpServer>
#include <QTcpSocket>
#include <QString>
namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = nullptr);
    ~Widget();
    QTcpServer* TcpServer;
    QTcpSocket* TcpSocket;

private slots://槽函数
    void on_open_bt_clicked();
    void NewCommunication_Slot();
    void ReadyRead_Slot();
    void on_clos_bt_clicked();
    void on_send_bt_clicked();

private:
    Ui::Widget *ui;
};

#endif // WIDGET_H
