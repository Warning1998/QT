#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    TcpServer = new QTcpServer(this);//创建一个TcpServer类
    TcpSocket = new QTcpSocket(this);//创建一个TcpSocket类

    connect(TcpServer,SIGNAL(newConnection()),this,SLOT(NewCommunication_Slot())); //关联信号和槽，当有新的客户端连接时，就执行槽函数的命令
}

Widget::~Widget()
{
    delete ui;
}

void Widget::on_open_bt_clicked()
{
    TcpServer->listen(QHostAddress::Any,ui->port_num->text().toUInt());//监听一切的可用端口
}

void Widget::NewCommunication_Slot()
{
    TcpSocket = TcpServer->nextPendingConnection();//等待新的连接
    connect(TcpSocket,SIGNAL(readyRead()),this,SLOT(ReadyRead_Slot()));//关联信号的槽，当有读取信号时，执行读取槽函数的命令
}

void Widget::ReadyRead_Slot()
{
    QString buffer;//创建一个缓冲区，用于接收发来的信息
    buffer = TcpSocket->readAll();//将读取到的所有内容存到缓冲区
    ui->data_receive->appendPlainText(buffer);//将缓冲区的内容以append的方式传入data_receive控件中
}

void Widget::on_clos_bt_clicked()
{
    TcpServer->close();//关闭服务器
}

void Widget::on_send_bt_clicked()
{
    TcpSocket->write(ui->data_edit->text().toLocal8Bit().data());//将data_edit控件中的数据都发送出去
}
