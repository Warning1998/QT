#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QFile>//添加file头文件
#include <QDir>//添加file头文件
#include <QDateTime>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    ///创建目录
    QString selectedFile = QDir::currentPath() + "/Video/";
    // 检查目录是否存在，若不存在则新建
    QDir dir;
    if(!dir.exists(selectedFile))
    {//Creates the directory path dirPath
       dir.mkpath(selectedFile);
    }
    ///创建文件
    QDateTime curDateTime = QDateTime::currentDateTime(); //获取当前时间
    QString xcurTime = curDateTime.toString("yyMdHmm");   //设置时间格式
    QFile file(selectedFile+xcurTime+".txt"); //创建文件

    file.open(QIODevice::WriteOnly);//创建txt

}

MainWindow::~MainWindow()
{
    delete ui;
}

